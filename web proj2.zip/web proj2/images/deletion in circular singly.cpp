#include<iostream>
using namespace std;
 struct node{
 	int data;
 	node* next;
 };
 
 int main()
 {
 	node* one= new node();
  	node* two= new node();
 	node* three= new node();
 	node*head;
 	
 	head=one;
 	
 	one->data=2;
 	one->next=two;
 	two->data=4;
 	two->next=three;
 	three->data=6;
 	three->next=head;

	
	//delete at the beginning;
//	three->next=head->next;
//	head=head->next;
//	delete one;
	
	
	//at the end;
	two->next=head;
	delete three;
	
	
	
	
	
	 node* temp= new node();
 	temp=head;
 	
 	do{
 		cout<<temp->data;
 		temp=temp->next;
	 }while(temp!=head);


 }
 
 
 
